# CONTROL Resonant: Arabic re-localization handoff

For the Claude session that continues this job. Read all of this first. Everything needed is inside this package.

## Goal
Replace the poor Gemini Arabic translation of the Arabic mod for CONTROL Resonant with a clean, professional Modern Standard Arabic localization. It is translated from the game's English text. The user's choices are fixed:
- Full retranslation of all game text.
- Profanity stays **strong**.
- **Hybrid** models: dialogue, choices and menu/UI batches use the top model. Documents, lore, JRPG and legal batches ("other-doc") can use a faster model (sonnet).

## State at handoff (Sept 25, 21:00 Baghdad)
- The game text was split into **133 batches** (`loc/batches/cNNN.json`, 20,178 items, ~266k English words).
- **34 are done and validated** (`loc/out/cNNN.json`). **99 are pending.** Run `python3 loc/pending.py 4 2` to list them. It prints JSON with top-model groups (`opus_groups`) and fast-model groups (`fast_groups`).
- The glossary is finished (`loc/glossary.json`: 361 characters with verified genders, 1,358 terms). The style guide is `loc/STYLE_GUIDE.md`.
- The font swap (Adobe Naskh Medium) is **already installed** in the user's game. A backup of the user's original English files already exists on their PC at `D:\games\CONTROL Resonant\_backup_before_arabic_patch\`.

## Setup
Unzip this package so the folder layout stays as-is: `work/loc/...`, `work/orig/...`, and the `*.py` files in `work/`. Then:

```bash
pip install lz4 fonttools   # lz4 is required by the packer
```

## Step 1: translate the pending batches
For each pending batch id `cNNN`, run one sub-agent (Agent tool; run several in parallel) with the prompt in `loc/TRANSLATOR_PROMPT.md`. Before sending, replace:
- `{BASE}` with the absolute path of the `loc` folder
- `{BATCH}` with the batch id

Give fast-group batches to a sonnet sub-agent. Each agent writes `loc/out/cNNN.json` and must reach 0 problems in `python3 loc/validate.py cNNN`.

Re-run `python3 loc/pending.py` until it reports 0 pending. Only launch batches that are not already done.

## Step 2: quality checks
```bash
python3 loc/qa.py      # name/gender heuristics -> loc/qa_report.json
```
Fix real problems by editing the specific ids in `loc/out/*.json`, then re-run the validator. Known false positive: lines where Dylan speaks to Zoe, Pope or Jesse correctly use the feminine "you".

Term harmonization (not covered by the glossary). Settle on one rendering for each of these across all out files:
- **CFD:** keep it Latin, as «جهاز CFD».
- **Fra Mauro's nicknames:** Shepard = شيبرد, Roosa = روسا.
- **"shape people":** use one form, either «شعب الأشكال» or «أهل الأشكال».

## Step 3: build the game files
```bash
python3 loc/assemble.py
```
This writes `loc/build/data_pack2/pc/base-en.rmdtoc`, `base-en-000.rmdblob`, `stream0-en.rmdtoc` and `stream0-en-000.rmdblob`. They are rebuilt from the user's ORIGINAL English files in `work/orig`, which match their game version. The script also fills the speaker-name labels from the glossary and verifies every file inside.

## Step 4: deliver
Give those 4 files to the user, for example by committing them to the repo. The user copies them into `D:\games\CONTROL Resonant\data_pack2\pc\` and replaces the existing files. The generic/font files are already installed. To uninstall, restore from `_backup_before_arabic_patch`.

## File map
- `loc/en_all.json`: English source `[key, text]`
- `loc/dialogue_ordered.txt`: dialogue in scene order, for context
- `loc/units.json`: translation units mapped to string-table keys
- `loc/make_batches.py`: already run; do not re-run, because it renumbers the batches
- `loc/validate.py`: per-batch checker for tags, timecodes, font characters and untranslated text
- `loc/assemble.py`: builds the string table and dialogue files, then repacks them (`packer.py`, `toc.py`, `rmdl.py`)
- `loc/translate_wf.js`: the original multi-agent workflow script (same prompt as `TRANSLATOR_PROMPT.md`)
