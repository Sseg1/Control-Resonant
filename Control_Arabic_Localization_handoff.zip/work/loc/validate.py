#!/usr/bin/env python3
"""Validate a translated batch.  Usage: python3 validate.py <batch_id>   (e.g. b007)
Reads loc/batches/<id>.json and loc/out/<id>.json, prints problems, exit 0 only if clean."""
import json, re, sys, os, collections
BASE = os.path.dirname(os.path.abspath(__file__))
CMAP = set(json.load(open(os.path.join(BASE, 'font_cmap.json')))) | {0x25A0, 0x200B, 0x0A, 0x0D}
TAG = re.compile(r'</?[A-Za-z][^<>]*>')
BRACE = re.compile(r'\{[^{}]*\}')
PCT = re.compile(r'%\d*\$?[sdif]')
ENT = re.compile(r'&[a-z]+;')
TC = re.compile(r'\[\d+(?:\.\d+)?-\d+(?:\.\d+)?\]')
ARABIC = re.compile(r'[؀-ۿ]')
LATIN_WORD = re.compile(r'[A-Za-z]{2,}')


def strip_markup(s):
    s = TAG.sub(' ', s); s = BRACE.sub(' ', s); s = PCT.sub(' ', s); s = ENT.sub(' ', s); s = TC.sub(' ', s)
    return s


def check(en, ar, allow_latin=()):
    errs = []
    if not isinstance(ar, str):
        return ['translation is not a string']
    if en.strip() == '':
        return [] if ar.strip() == '' else ['English is empty, Arabic must be empty']
    if ar.strip() == '':
        return ['empty translation']
    for name, rx in (('tag', TAG), ('placeholder', BRACE), ('printf', PCT), ('entity', ENT)):
        a, b = collections.Counter(rx.findall(en)), collections.Counter(rx.findall(ar))
        if a != b:
            errs.append(f'{name} mismatch: missing {dict(a - b)} extra {dict(b - a)}')
    te, ta = TC.findall(en), TC.findall(ar)
    if te != ta:
        errs.append(f'timecodes must be identical and in the same order: expected {te} got {ta}')
    elif te:
        if TC.match(en.lstrip()) and not TC.match(ar.lstrip()):
            errs.append('must start with the first timecode like the English')
        segs_e = TC.split(en); segs_a = TC.split(ar)
        for i, (se, sa) in enumerate(zip(segs_e, segs_a)):
            if se.strip() and not sa.strip():
                errs.append(f'timecode segment {i} is empty (each segment must be translated in place)')
    for ch in ('\n', '\r', '■', '<', '>', '[', ']'):
        if en.count(ch) != ar.count(ch):
            errs.append(f'count of {ch!r} differs: English {en.count(ch)}, Arabic {ar.count(ch)}')
    bad = sorted({c for c in ar if ord(c) not in CMAP})
    if bad:
        errs.append('characters not in the game font: ' + ' '.join(f'{c!r}(U+{ord(c):04X})' for c in bad))
    plain_en = strip_markup(en)
    plain_ar = strip_markup(ar)
    if LATIN_WORD.search(plain_en) and not ARABIC.search(plain_ar):
        if ar != en:
            errs.append('no Arabic text in translation')
        elif not (re.fullmatch(r'[A-Z0-9 .:+\-/#&%©®]*', plain_en.strip()) or len(plain_en.split()) <= 2):
            errs.append('left untranslated (identical to English)')
    # leftover English words (lowercase words of 4+ letters are almost always untranslated English)
    left = [w for w in re.findall(r'\b[a-z]{4,}\b', plain_ar) if w not in allow_latin]
    if left and ARABIC.search(plain_ar):
        errs.append(f'English words left in Arabic: {left[:6]}')
    return errs


def main(bid):
    batch = json.load(open(os.path.join(BASE, 'batches', bid + '.json')))
    outp = os.path.join(BASE, 'out', bid + '.json')
    if not os.path.exists(outp):
        print(f'MISSING output file {outp}'); return 2
    try:
        out = json.load(open(outp, encoding='utf-8'))
    except Exception as e:
        print(f'INVALID JSON in {outp}: {e}'); return 2
    problems = 0
    ids = [it['id'] for it in batch['items']]
    for i in ids:
        if i not in out:
            print(f'{i}: MISSING'); problems += 1
    for k in out:
        if k not in ids:
            print(f'{k}: unexpected id'); problems += 1
    for it in batch['items']:
        if it['id'] in out:
            for e in check(it['en'], out[it['id']]):
                print(f"{it['id']}: {e}"); problems += 1
    print(f'{bid}: {len(ids)} items, {problems} problem(s)')
    return 0 if problems == 0 else 1


if __name__ == '__main__':
    sys.exit(main(sys.argv[1]))
