#!/usr/bin/env python3
"""Cross-batch QA over out/*.json: glossary-name consistency + gender heuristics. Writes qa_report.json."""
import json, os, re, collections
BASE = os.path.dirname(os.path.abspath(__file__))
units = json.load(open(os.path.join(BASE, 'units.json')))
gl = json.load(open(os.path.join(BASE, 'glossary.json')))
tr = {}
for f in sorted(os.listdir(os.path.join(BASE, 'out'))):
    if f.endswith('.json'):
        tr.update(json.load(open(os.path.join(BASE, 'out', f), encoding='utf-8')))
# per-item english + speaker (from batch files)
meta = {}
for f in os.listdir(os.path.join(BASE, 'batches')):
    b = json.load(open(os.path.join(BASE, 'batches', f)))
    for it in b['items']:
        meta[it['id']] = (b['batch'], it['key'], it.get('speaker', ''), it['en'])

issues = collections.defaultdict(list)
AR_STRIP = re.compile(r'^(ال|د\.\s*|الدكتور[ة]?\s+|العميل[ة]?\s+|الحارس[ة]?\s+|السيد[ة]?\s+)')

# 1) names: each English name variant -> required Arabic core token
_en_all = json.load(open(os.path.join(BASE, 'en_all.json')))
COMMON_LC = collections.Counter(w for k, v in _en_all for w in re.findall(r'\b[a-z]{4,}\b', v))
name_rules = []
for c in gl['characters']:
    ens = [e.strip() for e in re.split(r'\s*/\s*', c['english']) if e.strip()]
    ars = [a.strip() for a in re.split(r'\s*/\s*', c['arabic']) if a.strip()]
    for e in ens:
        last_en = e.split()[-1]
        if len(last_en) < 4 or not last_en[0].isupper() or last_en.lower() in ('ranger', 'agent', 'worker', 'scientist', 'speaker', 'voice', 'whispers', 'caller', 'member', 'civilian', 'guard', 'loudspeaker', 'machine', 'recording', 'terminal', 'announcement', 'partygoer', 'technician'):
            continue
        if COMMON_LC.get(last_en.lower(), 0) > 3:
            continue
        cores = set()
        for a in ars:
            for w in a.split():
                w = AR_STRIP.sub('', w).strip('()')
                if len(w) >= 3 and w not in ('المصابة', 'بالعفن', 'المكتب'):
                    cores.add(w)
        cores = {x for x in cores if len(x) >= 2}
        if cores:
            name_rules.append((re.compile(r'(?<![A-Za-z])' + re.escape(last_en) + r'(?![A-Za-z])'), last_en, cores))
for uid, ar in tr.items():
    m = meta.get(uid)
    if not m:
        continue
    en = m[3]
    for rx, en_name, cores in name_rules:
        if rx.search(en) and not any((core[:-1] if core.endswith('ة') else core) in ar for core in cores):
            issues['name'].append({'id': uid, 'batch': m[0], 'name': en_name, 'expected_any': sorted(cores), 'en': en[:160], 'ar': ar[:160]})

# 2) gender heuristics
FEM_SPEAKERS = ('(female)',)
MASC_ADJ = r'(متأكد|آسف|مستعد|جاهز|سعيد|قلق|متعب|خائف|بخير الآن|مسرور|ممتن|واثق|مصاب|عالق|مستيقظ|وحيد|غاضب)'
for uid, ar in tr.items():
    m = meta.get(uid)
    if not m:
        continue
    bid, key, spk, en = m
    plain = re.sub(r'<[^>]*>|\[[\d.\-]+\]', ' ', ar)
    if spk.startswith('Dylan (male)') or key.startswith('CHOICE_'):
        if re.search(r'(أنا|لستُ|لست|كنتُ)\s+' + MASC_ADJ + r'ة\b', plain):
            issues['dylan_feminine_self'].append({'id': uid, 'batch': bid, 'en': en[:160], 'ar': ar[:160]})
    if '(female)' in spk:
        if re.search(r'\bأنا\s+' + MASC_ADJ + r'\b(?!ة)', plain):
            issues['female_masc_self'].append({'id': uid, 'batch': bid, 'spk': spk[:30], 'en': en[:160], 'ar': ar[:160]})
    # feminine 2nd person where the addressee is most likely Dylan (speaker isn't Dylan)
    if spk and not spk.startswith('Dylan') and re.search(r'\bأنتِ\b|[كت]ِ\b|\bت\w{2,}ين\b', plain) and re.search(r'\b(Dylan|Faden|P6)\b', en):
        issues['fem_address_to_dylan'].append({'id': uid, 'batch': bid, 'spk': spk[:30], 'en': en[:160], 'ar': ar[:160]})
    # UI/objectives addressing the player with feminine forms
    if not spk and re.search(r'\bأنتِ\b|\bت\w{2,}ين\b', plain) and re.search(r'\byou\b', en, re.I) and not key.startswith(('JRPG', 'OPCON', 'LST_')):
        issues['ui_feminine_you'].append({'id': uid, 'batch': bid, 'key': key, 'en': en[:160], 'ar': ar[:160]})

summary = {k: len(v) for k, v in issues.items()}
json.dump({'summary': summary, 'issues': issues}, open(os.path.join(BASE, 'qa_report.json'), 'w'), ensure_ascii=False, indent=1)
print('translated items', len(tr), 'QA', summary)
