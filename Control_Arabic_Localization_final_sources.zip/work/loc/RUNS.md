# Arabic re-localization — run log (for recovery)

Pipeline (all in /home/claude/work/loc):
- en_all.json (English source), glossary.json (merged: gl_chars_main/minor, gl_world_terms, gl_ui_terms), STYLE_GUIDE.md
- make_batches.py (BATCH_PREFIX=c) -> batches/cNNN.json, units.json, display_keys.json, batch_index.json (133 batches)
- translate_wf.js: one agent per batch -> out/cNNN.json, self-validated with validate.py
- assemble.py -> build/data_pack2/pc/{base-en,stream0-en}.rmdtoc + -000.rmdblob (repacked from the user's ORIGINAL English toc/blob in ../orig)
- Install: backup already exists at D:\games\CONTROL Resonant\_backup_before_arabic_patch (original English files). Commit build files to D:\games\CONTROL Resonant\data_pack2\pc\ (font patch generic files already installed).

Translation workflows (6 groups, batches round-robin i::6):
- g0 task wnj38zgqx run wf_7025aa73-499
- g1 task w1rs92fcu run wf_79f74de1-22b
- g2 task wj3uuw2si run wf_2a39aaa7-f1c
- g3 task wluwbn5vp run wf_8604cb31-fee
- g4 task well70riv run wf_371e4773-540
- g5 task w9qzzsnbh run wf_799bcda3-9e0
Resume a failed/limited group: Workflow({scriptPath:'/home/claude/work/loc/translate_wf.js', resumeFromRunId:'<run>', args:{batches:[...same list...]}})
Missing batches can also simply be relaunched with a new args list (only those without a clean out/ file).
User choices: full redo, profanity KEEP STRONG, MSA.

## Model choice (user, 15:20): HYBRID
- dialogue / choice / UI batches: default model (inherit, top model)
- documents / lore / JRPG / legal ("other-doc"): args.model = 'sonnet'
- `python3 pending.py 4 2` prints pending batches split into 4 top-model groups + 2 fast groups (JSON); launch translate_wf.js once per group with args {batches:[...]} (+ model:'sonnet' for fast groups).
- Wake-up scheduled: trig_015sdrgKeCZD3dk2t7PhzJ7G at 19:33 Baghdad.

## Run 2 (15:21, user said "keep going") — hybrid
- opus g0 wxs51r01n wf_fd1bf544-e2c | g1 wgm9op2jz wf_f72cdac4-fcc | g2 wwq8027mg wf_38419e01-aef | g3 wafb7kd84 wf_6910aade-e3e
- sonnet f0 wtt2kzhkq wf_895a96b4-7b8 | f1 wwi3jgxov wf_60033ebe-fb7

## Run 3 (20:42, after 8:10pm reset) — 23/133 done before this run
- opus wlcfty761 wf_54dc9d2a-594 | w6tluqhci wf_ea407386-b6c | w34258a7z wf_682ba3e3-81a | wl7cnubvo wf_d36b125d-92e
- sonnet wsswmdrdr wf_a24ded7b-2c5 | whp62ub9i wf_a96e8709-541
