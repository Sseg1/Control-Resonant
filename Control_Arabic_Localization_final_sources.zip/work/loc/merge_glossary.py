import json, os
main=json.load(open('gl_chars_main.json')); minor=json.load(open('gl_chars_minor.json'))
chars=[]; seen_id=set(); seen_en=set()
for c in main+minor:
    if c['speakerId']:
        if c['speakerId'] in seen_id: continue
        seen_id.add(c['speakerId'])
    else:
        if c['english'] in seen_en: continue
        seen_en.add(c['english'])
    chars.append(c)
# fix-ups decided on review
for c in chars:
    if c['speakerId']=='RANGERSINGH' and c['english']=='Ranger Jones': pass
terms=[]
for f in ('gl_world_terms.json','gl_ui_terms.json'):
    if os.path.exists(f):
        for t in json.load(open(f)):
            if f.startswith('gl_ui'): t['category']='ui'
            terms.append(t)
json.dump({'characters':chars,'terms':terms},open('glossary.json','w'),ensure_ascii=False,indent=0)
print('characters',len(chars),'terms',len(terms))
