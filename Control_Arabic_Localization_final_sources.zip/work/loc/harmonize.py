#!/usr/bin/env python3
"""Cross-batch term harmonization over out/*.json (idempotent). Usage: python3 harmonize.py [--dry]"""
import json, os, re, sys
BASE = os.path.dirname(os.path.abspath(__file__))
DRY = '--dry' in sys.argv

meta = {}
for f in os.listdir(os.path.join(BASE, 'batches')):
    b = json.load(open(os.path.join(BASE, 'batches', f)))
    for it in b['items']:
        meta[it['id']] = (b['batch'], it['key'], it['en'])

files = {}
for f in sorted(os.listdir(os.path.join(BASE, 'out'))):
    if f.endswith('.json'):
        files[f[:-5]] = json.load(open(os.path.join(BASE, 'out', f), encoding='utf-8'))
owner = {i: b for b, d in files.items() for i in d}
changes = []


def sub_id(i, old, new, count=0):
    """Literal replacement inside one item."""
    if i not in owner:
        print('!! missing id', i); return
    d = files[owner[i]]
    if old not in d[i]:
        if new not in d[i]:
            print(f'!! {i}: pattern not found: {old!r}')
        return
    d[i] = d[i].replace(old, new) if not count else d[i].replace(old, new, count)
    changes.append((i, old, new))


def set_id(i, new):
    d = files[owner[i]]
    if d[i] != new:
        changes.append((i, d[i][:60], new[:60])); d[i] = new


def sub_all(rx, repl, en_filter=None, skip=()):
    for b, d in files.items():
        for i, a in d.items():
            if i in skip:
                continue
            if en_filter and not re.search(en_filter, meta[i][2]):
                continue
            na = re.sub(rx, repl, a)
            if na != a:
                changes.append((i, a[:50], na[:50])); d[i] = na


# 1) CFD -> «جهاز CFD» (glossary: Latin CFD; «منصة CFD», «كارثة CFD» stay)
CFD_SKIP = {'d00288'}  # "…the Cancellation Field Device, or CFD" definition line
sub_all(r'الـ ?CFD', 'جهاز CFD', skip=CFD_SKIP)
sub_all(r'(?<![\w(])([لب])ـ ?CFD', r'\1جهاز CFD', skip=CFD_SKIP)
sub_all(r'(?<!جهاز )(?<!منصة )(?<!منصّة )(?<!كارثة )(?<![(\w])CFD\b', 'جهاز CFD', skip=CFD_SKIP)
# dialogue lines that spelled out "CFD" as the full Arabic name
sub_all(r'جهاز حقل الإلغاء', 'جهاز CFD', en_filter=r'^(?!.*Cancel+ation Field Device).*\bCFD\b')
sub_all(r'جهاز جهاز CFD', 'جهاز CFD')

# 2) AWE -> «حدث تبدُّل العالم» (Langston's A.W.E. word play keeps the Latin letters)
AWE_SKIP = {i for i, m in meta.items() if 'A. W. E.' in m[2] or 'I in AWE' in m[2]}
sub_all(r'حدث AWE', 'حدث تبدُّل العالم', skip=AWE_SKIP)
sub_all(r'تقرير AWE', 'تقرير حدث تبدُّل العالم', skip=AWE_SKIP)
sub_all(r'حدث العالم المتغيّر', 'حدث تبدُّل العالم')
sub_id('u01469', 'زي مهمات أحداث تبدُّل العالم', 'زي مهمة AWE')

# 3) "shape people" -> «أهل الأشكال»
sub_all(r'شعب الأشكال', 'أهل الأشكال')

# 4) parautilitarian -> «صاحب قدرات خارقة»
sub_id('d01609', 'من مستخدمي الخوارق الأقوياء', 'من أصحاب القدرات الخارقة الأقوياء')
sub_id('d01611', 'مجرد مستخدمين عاديين للخوارق', 'مجرد أصحاب قدرات خارقة عاديين')
sub_id('u02136', 'خارق نفعي؟', 'صاحب قدرات خارقة؟')

# 5) Rangers -> «الحرّاس»
sub_id('u02711', 'لتقارير الحرس', 'لتقارير الحرّاس')
sub_id('u02840', 'الحرس', 'الحرّاس')
sub_id('u02964', 'والرينجرز', 'والحرّاس')

# 6) Map Kit pylon -> «البرج»
sub_all(r'عمود رسم الخرائط', 'برج رسم الخرائط')

# 7) Fred's "ping-pong" / "drifter"
sub_id('d07975', 'شيبرد، أنت كرة طاولة.', 'شيبرد، أنت بينغ بونغ.')
sub_id('d05530', 'شيبرد، أنت كرة طاولة!', 'شيبرد، أنت بينغ بونغ!')
sub_id('c01409', '«الهائمة» تعني.. الأخت؟', '«شقيّتي» تعني.. شقيقتي؟')
sub_id('d05565', 'مثل هائمك', 'مثل شقيّتك')

# 8) debug ability selectors use the official ability names (glossary)
for i, new in {'c00190': 'دفقة الأبواغ', 'c00236': 'الأتون', 'c00314': 'اختيار الشوكة',
               'c00543': 'اختيار الأتون', 'c00749': 'الزجر النجمي', 'c01012': 'الإشعال',
               'c01029': 'اختيار الزجر النجمي', 'c01063': 'النموّ', 'c01276': 'اختيار الشذوذ المتقلّب',
               'c01821': 'قدرة النموّ'}.items():
    set_id(i, new)
for i in ('c00432', 'c00692', 'c00694', 'c00717', 'c00780', 'c01225', 'c01301'):  # "Draw"
    set_id(i, 'رسم')

# 9) misc single-term fixes
sub_all(r'الإصابة الحرجة', 'الضربة الحرجة')                       # Critical (glossary: ضربة حرجة)
sub_all(r'وإنجازات العالم', 'والمآثر الميدانية')                  # World Feats (glossary)
sub_all(r'تصميم مبدئي', 'تصميم مفاهيمي')                          # gallery "concept"
sub_id('u03131', 'شقة الجامع', 'شقة المُقتني')                     # Collector (c077)
set_id('u02737', 'تأثيرات الحالة')                                 # "Status Effects Remove me" (dev note)
# Board speech the checker mistook for a tag
set_id('d09042', '[0.03-2.43]< إنها مجرد أصداء/معاناة/شبح >')

# 9b) glossary spellings of names flagged by qa.py
sub_all(r'ميلبك', 'ميلبيك')
sub_all(r'آميري', 'أميري')
sub_all(r'بوتشالسكي', 'بوخالسكي')

sub_all(r'لـ ?Third Ice', 'لـ«ثيرد آيس»')
sub_all(r'Third Ice', 'ثيرد آيس')                                 # NVIDIA tie-in brand, as in c082

sub_id('u05461', '«Onnea Uuteen Kotiin!»', '«أونيا أوتين كوتيين!»')         # Finnish, transliterated like other Finnish lines

# 10) EULA: URLs and list numerals exactly like the English
sub_id('u01486~002', 'HTTPS://REMEDY.HELPSHIFT.COM/', 'https://remedy.helpshift.com/')
en4 = meta['u01486~004'][2]
m = re.search(r'www\.remedygames\.com/privacy-policy', en4, re.I)
if m:
    sub_id('u01486~004', 'WWW.REMEDYGAMES.COM/PRIVACY-POLICY', m.group(0))
for r in ('VIII', 'VII', 'VI', 'IV', 'IX', 'III', 'II', 'V', 'I'):
    sub_id('u01486~007', f'({r})', f'({r.lower()})')

print(f'{len(changes)} change(s)')
for c in changes[:400]:
    print('  ', c[0], '|', c[1].replace('\n', ' ')[:60], '=>', c[2].replace('\n', ' ')[:60])
if not DRY:
    touched = {owner[c[0]] for c in changes}
    for b in touched:
        json.dump(files[b], open(os.path.join(BASE, 'out', b + '.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    print('rewrote', sorted(touched))
