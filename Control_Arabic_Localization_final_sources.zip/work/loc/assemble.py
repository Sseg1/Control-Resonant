#!/usr/bin/env python3
"""Merge translated batches into the Arabic string table + dialogue (RMDL) files and repack base-en / stream0-en."""
import json, os, re, struct, sys, collections
BASE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.dirname(BASE)
sys.path.insert(0, WORK)
from toc import read_toc, files, read_file
from rmdl import parse as rmdl_parse, build as rmdl_build
from packer import repack, verify

en = json.load(open(os.path.join(BASE, 'en_all.json')))
units = json.load(open(os.path.join(BASE, 'units.json')))
gl = json.load(open(os.path.join(BASE, 'glossary.json')))
display_keys = set(json.load(open(os.path.join(BASE, 'display_keys.json')))['display_keys'])
spk_disp = json.load(open(os.path.join(BASE, 'speakers.json')))

tr = {}
for f in sorted(os.listdir(os.path.join(BASE, 'out'))):
    if f.endswith('.json'):
        tr.update(json.load(open(os.path.join(BASE, 'out', f), encoding='utf-8')))
missing_units = [u for u in units if u not in tr]
# re-join split long strings
for uid, u in units.items():
    if u.get('parts'):
        ps = [tr.get(f'{uid}~{i:03d}') for i in range(u['parts'])]
        if all(p is not None for p in ps):
            tr[uid] = ''.join(ps)
missing_units = [u for u in units if u not in tr]
key2ar = {}
for uid, u in units.items():
    if uid in tr:
        for k in u['keys']:
            key2ar[k] = tr[uid]
# speaker display labels from the character glossary
by_id = {c['speakerId']: c for c in gl['characters'] if c.get('speakerId')}
lbl_missing = []
for k in display_keys:
    sid = re.sub(r'[^A-Z0-9]', '', k.upper())
    c = by_id.get(sid)
    if c and c['arabic']:
        key2ar[k] = c['arabic']
    else:
        lbl_missing.append(k)

final = []
fallback = 0
for k, v in en:
    if k in key2ar:
        final.append((k, key2ar[k]))
    else:
        final.append((k, v)); fallback += 1
print(f'units translated {len(units) - len(missing_units)}/{len(units)}; label gaps {len(lbl_missing)}; English fallbacks {fallback}')
if missing_units:
    print('missing units sample', missing_units[:10])
if lbl_missing:
    print('label gaps', lbl_missing[:20])

def build_st(pairs):
    out = bytearray(struct.pack('<I', len(pairs)))
    for k, v in pairs:
        kb = k.encode('utf8'); vb = v.encode('utf-16-le')
        out += struct.pack('<I', len(kb)) + kb + struct.pack('<I', len(vb) // 2) + vb
    return bytes(out)

st_bytes = build_st(final)

# dialogue RMDL files: map (speaker label, normalized English) -> Arabic without timecodes
TC = re.compile(r'\[\d+(?:\.\d+)?-\d+(?:\.\d+)?\]')
norm = lambda t: re.sub(r'\s+', ' ', TC.sub(' ', t)).strip()
ar_by_text = collections.defaultdict(collections.Counter)
enmap = dict(en)
for k, a in final:
    e = enmap[k]
    if e.strip():
        ar_by_text[norm(e)][norm(a)] += 1

def rmdl_replace(pk, tocp, blobp):
    h, ch, dec, raw = read_toc(tocp)
    blob = open(blobp, 'rb').read()
    rep = {}; miss = 0; tot = 0
    for f in files(h, dec):
        if f['name'] == 'string_table.bin':
            continue
        d = read_file(h, dec, [blob], f)
        o = rmdl_parse(d)
        for e in o['entries']:
            tot += 1
            cands = ar_by_text.get(norm(e['text']))
            if cands:
                e['text'] = cands.most_common(1)[0][0]
            elif e['text'].strip():
                miss += 1
        rep[f['name']] = rmdl_build(o)
    print(f'{pk}: {tot} dialogue entries, {miss} without translation')
    return rep

os.makedirs(os.path.join(BASE, 'build', 'data_pack2', 'pc'), exist_ok=True)
for pk in ('base-en', 'stream0-en'):
    tocp = os.path.join(WORK, 'orig', 'data_pack2', 'pc', pk + '.rmdtoc')
    blobp = os.path.join(WORK, 'orig', 'data_pack2', 'pc', pk + '-000.rmdblob')
    rep = rmdl_replace(pk, tocp, blobp)
    if pk == 'base-en':
        rep['string_table.bin'] = st_bytes
    ot = os.path.join(BASE, 'build', 'data_pack2', 'pc', pk + '.rmdtoc')
    ob = os.path.join(BASE, 'build', 'data_pack2', 'pc', pk + '-000.rmdblob')
    n = repack(tocp, blobp, rep, ot, ob)
    bad = verify(ot, ob, rep)
    print(f'{pk}: blob {n} bytes, verify mismatches {bad}')
json.dump(final, open(os.path.join(BASE, 'ar_final.json'), 'w'), ensure_ascii=False)
