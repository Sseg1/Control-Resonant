# CONTROL Resonant — Arabic localization style guide

Target: clean, professional, natural Modern Standard Arabic (الفصحى المعاصرة), the quality of an official AAA Arabic release. Translate meaning and tone, never word-for-word. Every line must read as if originally written in Arabic.

## Register
- UI, menus, tutorials, item/ability text: concise, neutral, standard gaming Arabic. Menu items are short nouns or verbal nouns (مصادر): "متابعة"، "الإعدادات"، "الخروج إلى القائمة الرئيسية". Buttons/prompts use short imperatives or verbal nouns consistently.
- Dialogue: natural spoken MSA — light, direct, contemporary (e.g. "لنذهب"، "ماذا يحدث؟"، "هل أنت بخير؟"). No dialect, no stiff/archaic wording, no literal calques of English idioms — use the Arabic idiom with the same meaning.
- Documents/lore (FBC reports, memos, logs): formal bureaucratic MSA, like a government agency. Keep redaction bars ■ exactly as in the source (same count, same position relative to the sentence).
- The Board speaks in its signature bracketed alternatives: "< The Director/Sibling/Favorite has gone AWOL/Fishing/??? >". Keep "< " and " >" and the slash-separated alternatives structure; translate each alternative (keep deliberate oddness/humor).
- Profanity: KEEP IT STRONG (player's choice). Translate swearing with equally strong Arabic, not softened. Guide: fuck!/fuck me → "اللعنة!" / "تبًّا لي!"; fucking (adj) → "اللعين/اللعينة" or "الملعون"; shit! → "تبًّا!" / "اللعنة!" ; "this is shit" → "هذا خراء" / "هذا قذر"; bullshit → "هراء" / "كلام فارغ"; son of a bitch → "ابن العاهرة" / "ابن الكلب"; asshole → "حقير" / "وغد"; damn → "اللعنة"; goddamn → "اللعنة" / "الملعون"; holy shit → "يا للهول!" / "يا إلهي!" (intensity-appropriate); what the hell → "ما هذا بحق الجحيم؟". Vary naturally; do not overuse one word.

## Gender (critical — Arabic verbs, adjectives, pronouns and "you" forms are gendered)
- Dylan Faden (protagonist, the player) is MALE. Anything addressed to the player (UI, tutorials, objectives, hints, "you") uses MASCULINE singular.
- Jesse Faden is FEMALE (Dylan's sister, former FBC Director). Zoe De Vera is FEMALE. Emily Pope is FEMALE. Simon Arish is MALE. Use the glossary for every other character's gender.
- A speaker's own lines agree with the SPEAKER's gender ("I'm ready" → مستعد / مستعدة). The addressee's gender comes from context (who they are talking to). When Dylan speaks to Zoe/Pope/Jesse, "you" is feminine.
- Speaker gender unknown / generic voice (e.g. "BARKS RANGER 3", crowds, loudspeakers): prefer gender-neutral phrasing (verbal nouns, rephrasing: "إصابة!" instead of "أنا مصاب/مصابة"); if unavoidable, masculine.
- Groups: masculine plural unless clearly all-female.

## Names and terms
- Use the glossary's Arabic spelling for every name and term, every time. Transliterate personal names (never translate their meaning): Dylan = ديلان، Jesse = جيسي، Zoe = زوي. Keep call-signs/codes readable (P6 → P6 in Latin is fine; letters/numbers codes stay Latin).
- Don't leave English words in Arabic text except: acronyms/codes kept per glossary, Latin-only technical codes (e.g. "HRA-7"), and brand/format tokens in the glossary.

## Formatting (strict — the checker rejects violations)
- Keep EVERY markup token byte-identical and in a sensible position: HTML-like tags `<br>`, `<strong>…</strong>`, `<b>`, `<i>`, `<u>`, `<em>`, `<no-wrap>`, `<svg-icon key="…"></svg-icon>`, `<action-key …></action-key>`, `<map-marker …>`, `<p cohinline>`, `<li>`, `<ul>`; non-verbal tags like `<grunts>`, `<static>`, `<patterned speech>`, `<IDLE NEUTRAL 1>` stay EXACTLY as-is (they are markup, not text). Never translate attribute values (key="…").
- Placeholders stay exactly: `{ARG_0}`, `{AMOUNT}`, `{charm_…}`, `%s`, `%d`, `&quot;`.
- Subtitle timecodes `[0.26-5.79]` must all be kept, in the same order, each followed by the Arabic translation of the SAME segment that followed it in English (segment-by-segment; do not merge or move text across timecodes). Text before the first timecode (rare) stays before it.
- Keep the same number of real line breaks (\n / \r\n) as the source.
- Other square-bracket text like "[illegible]", "[crosstalk]", "[Cat delivered]" → translate the words, keep the brackets.
- Punctuation: Arabic comma "،", Arabic question mark "؟", Arabic semicolon "؛". Periods, "!", ":", "...", "…", "—", "-" as normal. Quotation marks: use «» for quotations. Digits: Western 0-9 (keep numbers exactly).
- Tashkeel (harakat): only where needed to avoid ambiguity or for shadda/tanween in common words (شكرًا، جدًّا). No full vocalization.
- Only use characters available in the game font: Arabic letters/marks, Western digits, ASCII punctuation, « » “ ” ‘ ’ — – … • ■, NBSP. No emoji, no other scripts, no Latin letters with accents.
- Empty English → empty Arabic. A string that is only a code/number/symbol → copy it unchanged.
