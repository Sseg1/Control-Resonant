#!/usr/bin/env python3
"""Fix the order of wrapped Arabic lines in the game's text renderer.

How the renderer behaves (worked out from in-game screenshots):
- text is split into style runs; each run is shaped right-to-left, so its glyphs come out in visual order;
- lines are filled walking the runs in logical order but each run's glyphs in that visual order, so a run
  that wraps puts its logical END on the first line;
- a text node that is only whitespace is dropped;
- the newline of <br> is appended to the preceding run (and so is reversed to its start).

The fix: every word becomes its own style run, with the space before it inside the run, and a zero-width
space run before line breaks so the break never lands inside a word run. All four installed fonts
(regular/bold/italic/bold-italic) are the same Arabic font, so the style tags change nothing visually.
Words get <i> (or <b> where the text is already italic, so the run still differs from its surroundings)."""
import re

TC_RX = r'\[\d+(?:\.\d+)?-\d+(?:\.\d+)?\]'
TOKEN = re.compile(r'(' + TC_RX + r'|</?[A-Za-z][^<>]*>|\s+)')
ARABIC = re.compile(r'[؀-ۿ]')
MARKUP = re.compile(r'</?(?:br|strong|b|i|u|em|p|li|ul|h\d|s|no-wrap|svg-icon|action-key|map-marker)\b[^<>]*>')
BLOCK = re.compile(r'</?(?:br|p|li|ul|ol|h\d)\b', re.I)
MIN_LEN = 35      # plain strings shorter than this fit on one line anywhere; leave them untouched
ZWSP = '​'   # invisible, non-whitespace: gives a line break its own run


def _visible(text):
    return re.sub(r'</?[A-Za-z][^<>]*>|' + TC_RX, '', text)


def needs_wrap(text):
    vis = _visible(text)
    if not ARABIC.search(vis) or len(vis.split()) < 2:
        return False
    return bool(MARKUP.search(text)) or len(vis.strip()) >= MIN_LEN


def _is_tag(tok):
    return bool(re.match(r'</?[A-Za-z]', tok)) and tok.endswith('>') and not tok.startswith('< ')


INLINE = re.compile(r'</?(?:b|strong|i|em|u|s|span|font|color|size)\b', re.I)


def wrap_words(text):
    """Every word becomes its own style run. The space before a word goes INSIDE that word's run as a leading
    space: in the right-to-left run it sits after the word's glyphs, so a line never starts with a space
    the engine could trim."""
    if not needs_wrap(text):
        return text
    toks = [t for t in TOKEN.split(text) if t]
    out = []              # emitted pieces
    last_word = None      # index in `out` of the most recent word run (inline tags may follow it)
    text_is_word = False  # the most recent text run is one of our word runs
    pending = ''          # whitespace waiting to become the leading space of the next word run
    bold = italic = nowrap = 0

    def settle():
        """No word run can take the pending space: give it to the previous word run as a trailing space."""
        nonlocal pending
        if pending and last_word is not None:
            o = out[last_word]; cut = o.rindex('</')
            out[last_word] = o[:cut] + pending + o[cut:]
        elif pending:
            out.append(pending)
        pending = ''

    for n, tok in enumerate(toks):
        if _is_tag(tok):
            m = re.match(r'<(/?)([A-Za-z][\w-]*)', tok)
            name = m.group(2).lower()
            if not (INLINE.match(tok) and not nowrap):
                settle()
                if text_is_word and BLOCK.match(tok):
                    out.append(ZWSP)       # the break's newline attaches to this run instead of the word
                    text_is_word = False
                last_word = None
            step = -1 if m.group(1) else 1
            if name in ('b', 'strong'):
                bold = max(0, bold + step)
            elif name in ('i', 'em'):
                italic = max(0, italic + step)
            elif name == 'no-wrap':
                nowrap = max(0, nowrap + step)
            out.append(tok)
        elif re.fullmatch(TC_RX, tok):
            settle()
            last_word = None; text_is_word = False
            out.append(tok)
        elif tok.isspace():
            if '\n' in tok or '\r' in tok:
                prev_tag = n == 0 or _is_tag(toks[n - 1])
                next_tag = n + 1 >= len(toks) or _is_tag(toks[n + 1])
                ws = pending + tok; pending = ''
                out.append(ws if prev_tag and next_tag else ZWSP + ws)   # newline in a run of its own
                last_word = None; text_is_word = False
            else:
                pending += tok
        elif nowrap or '<' in tok or '>' in tok:
            settle()
            out.append(tok)                        # no-wrap groups and Board "< … >" stay as they are
            last_word = None; text_is_word = False
        else:
            tag = 'b' if italic and not bold else 'i'
            out.append(f'<{tag}>{pending}{tok}</{tag}>'); pending = ''
            last_word = len(out) - 1; text_is_word = True
    settle()
    return ''.join(out)


SEP = '\u05d0'   # Hebrew alef, mapped to an empty zero-width glyph in the installed fonts (work/font_scale.py)


def _sep_line(line):
    """Plain text (no markup support): the renderer splits runs by script, so an invisible character of another
    right-to-left script between words makes every word its own right-to-left run. Lines are then filled word
    by word in reading order and each line's runs are laid out right-to-left, as with the style runs."""
    core = line.strip()
    if not ARABIC.search(core) or len(core.split()) < 2 or len(core) < MIN_LEN:
        return line
    lead = line[:len(line) - len(line.lstrip())]
    trail = line[len(line.rstrip()):]
    return lead + re.sub(r'(?<=\S)([ \t]+)(?=\S)', SEP + r'\1', core) + trail


def wrap_plain(text):
    parts = re.split('(' + TC_RX + r'|\r?\n)', text)   # subtitle segments and lines are laid out separately
    return ''.join(p if re.fullmatch(TC_RX + r'|\r?\n', p or '\n') else _sep_line(p) for p in parts)


def add_speaker(text, name):
    """Start every subtitle segment with the speaker's name, so it sits on the right like Arabic subtitles
    should (the game's own speaker label is a separate widget on the left; turn it off in the options)."""
    if not name:
        return text
    parts = re.split('(' + TC_RX + ')', text)
    out = []
    for p in parts:
        if p and not re.fullmatch(TC_RX, p) and ARABIC.search(_visible(p)):
            lead = p[:len(p) - len(p.lstrip())]
            p = f'{lead}{name}: {p.lstrip()}'
        out.append(p)
    return ''.join(out)


def wrap_display(text, english):
    """Strings whose English original uses markup are shown by rich-text widgets: use per-word style runs.
    Other strings may be shown by plain-text widgets (subtitles, menus) that print tags literally: use bidi
    control characters instead."""
    if MARKUP.search(english or ''):
        return wrap_words(text)
    return wrap_plain(text)


if __name__ == '__main__':
    for s in ('في كل عُدّة خرائط، عليك معايرة <strong>المستشعرات الثلاثة</strong>، ثم تفعيل <no-wrap><map-marker type="MapTower"></map-marker><strong>البرج</strong></no-wrap> المركزي لكشف خريطة المنطقة.',
              '[7.67-12.09]التقنية ليست بالتعقيد الذي تبدو عليه، لكنها تعمل. [12.52-13.87]في معظم الأحيان.',
              'يحدد اللغة.<br><br><i>(هذا الخيار متاح فقط من القائمة الرئيسية).</i>',
              'من أي نوع، <b>فاستشر طبيبك قبل اللعب.</b><br /><br />\r\n<b>توقّف فورًا</b> عن اللعب واستشر طبيبك',
              '[0.03-2.43]< إنها مجرد أصداء/معاناة/شبح >', 'الخروج إلى القائمة'):
        print(repr(wrap_words(s))); print()
