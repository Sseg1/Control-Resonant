#!/usr/bin/env python3
"""Fix the order of wrapped Arabic lines in the game's text renderer.

The renderer splits text into style runs, shapes each run right-to-left (glyphs come out in visual order),
then fills lines walking the runs in logical order but the glyphs of a run in that visual order. A run that
wraps therefore puts its logical END on the first line. Placing every word in its own style run makes the
line breaker consume words in reading order, and the renderer already places the runs of a line right-to-left.

All four installed fonts (regular/bold/italic/bold-italic) are the same Arabic font, so a style tag around a
word changes nothing visually; it only starts a new run. Words get <i> (or <b> where the text is already
italic so the run still differs from its surroundings)."""
import re

TOKEN = re.compile(r'(\[\d+(?:\.\d+)?-\d+(?:\.\d+)?\]|</?[A-Za-z][^<>]*>|\s+)')
ARABIC = re.compile(r'[؀-ۿ]')
MARKUP = re.compile(r'</?(?:br|strong|b|i|u|em|p|li|ul|h\d|s|no-wrap|svg-icon|action-key|map-marker)\b[^<>]*>')
MIN_LEN = 35   # plain strings shorter than this fit on one line anywhere; leave them untouched


def _visible(text):
    return re.sub(r'</?[A-Za-z][^<>]*>|\[\d+(?:\.\d+)?-\d+(?:\.\d+)?\]', '', text)


def needs_wrap(text):
    vis = _visible(text)
    if not ARABIC.search(vis) or len(vis.split()) < 2:
        return False
    return bool(MARKUP.search(text)) or len(vis.strip()) >= MIN_LEN


def wrap_words(text):
    if not needs_wrap(text):
        return text
    out = []
    bold = italic = nowrap = 0
    for tok in TOKEN.split(text):
        if not tok:
            continue
        m = re.match(r'<(/?)([A-Za-z][\w-]*)', tok)
        if m and tok.endswith('>') and not tok.startswith('< '):
            closing, name = m.group(1) == '/', m.group(2).lower()
            step = -1 if closing else 1
            if name in ('b', 'strong'):
                bold = max(0, bold + step)
            elif name in ('i', 'em'):
                italic = max(0, italic + step)
            elif name == 'no-wrap':
                nowrap = max(0, nowrap + step)
            out.append(tok)
        elif tok.isspace() or tok.startswith('[') and tok.endswith(']') and re.fullmatch(r'\[\d+(?:\.\d+)?-\d+(?:\.\d+)?\]', tok):
            out.append(tok)
        elif nowrap or '<' in tok or '>' in tok:
            out.append(tok)                      # keep no-wrap groups and Board "< … >" brackets as they are
        else:
            tag = 'b' if italic and not bold else 'i'
            out.append(f'<{tag}>{tok}</{tag}>')
    return ''.join(out)


if __name__ == '__main__':
    for s in ('في كل عُدّة خرائط، عليك معايرة <strong>المستشعرات الثلاثة</strong>، ثم تفعيل <no-wrap><map-marker type="MapTower"></map-marker><strong>البرج</strong></no-wrap> المركزي لكشف خريطة المنطقة.',
              '[7.67-12.09]التقنية ليست بالتعقيد الذي تبدو عليه، لكنها تعمل. [12.52-13.87]في معظم الأحيان.',
              'يحدد اللغة.<br><br><i>(هذا الخيار متاح فقط من القائمة الرئيسية).</i>',
              '[0.03-2.43]< إنها مجرد أصداء/معاناة/شبح >', 'الخروج إلى القائمة'):
        print(wrap_words(s)); print()
