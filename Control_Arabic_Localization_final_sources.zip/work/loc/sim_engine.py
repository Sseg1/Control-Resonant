import re
def engine(text, width):
    """Model of the game's text layout inferred from in-game screenshots."""
    nodes = re.split(r'(</?[A-Za-z][^<>]*>)', text)
    runs = []
    for nd in nodes:
        if not nd: continue
        if re.match(r'</?[A-Za-z]', nd):
            if re.match(r'<br', nd, re.I):
                if runs: runs[-1] += '\n'          # the break's newline joins the previous run
                else: runs.append('\n')
            continue
        if nd.replace('\r', '').strip(' \t\n') == '': continue   # whitespace-only node dropped
        runs.append(nd.replace('\r', ''))
    lines = [[]]; used = 0
    for r in runs:
        toks = re.findall(r'\n| +|[^ \n]+', r)[::-1]   # RTL-shaped run: visual order
        piece = []
        def flush():
            nonlocal piece
            if piece: lines[-1].append(''.join(piece[::-1]))
            piece = []
        for t in toks:
            if t == '\n':
                flush(); lines.append([]); used = 0; continue
            w = len(t.replace('​', ''))
            if t.strip() == '' and used == 0: continue
            if used + w > width and used > 0 and t.strip():
                flush(); lines.append([]); used = 0
            piece.append(t); used += w
        flush()
    return [''.join(p).replace('​', '') for p in lines]   # pieces of a line read right-to-left in logical order
