#!/usr/bin/env python3
"""Print pending batches split for launching: python3 pending.py [n_groups_opus] [n_groups_fast]"""
import json, os, subprocess, sys
BASE = os.path.dirname(os.path.abspath(__file__))
idx = json.load(open(os.path.join(BASE, 'batch_index.json')))
opus, fast = [], []
for b, n, w in idx:
    if os.path.exists(os.path.join(BASE, 'out', b + '.json')):
        r = subprocess.run([sys.executable, os.path.join(BASE, 'validate.py'), b], capture_output=True)
        if r.returncode == 0:
            continue
    d = json.load(open(os.path.join(BASE, 'batches', b + '.json')))
    keys = ' '.join(i['key'] for i in d['items'][:3])
    is_doc = d['kind'] == 'other' and any(x in keys for x in ('OPCON', 'LST_', 'EULA', 'PRIVACY', 'JRPG', 'TRANSCRIPT'))
    (fast if is_doc else opus).append(b)
go = int(sys.argv[1]) if len(sys.argv) > 1 else 4
gf = int(sys.argv[2]) if len(sys.argv) > 2 else 2
print(json.dumps({'opus_total': len(opus), 'fast_total': len(fast),
                  'opus_groups': [opus[i::go] for i in range(go) if opus[i::go]],
                  'fast_groups': [fast[i::gf] for i in range(gf) if fast[i::gf]]}))
