#!/usr/bin/env python3
"""Split the English string table into translation batches (loc/batches/bNNN.json) + unit map (loc/units.json)."""
import json, re, os, collections
BASE = os.path.dirname(os.path.abspath(__file__))
en = json.load(open(os.path.join(BASE, 'en_all.json')))
gl = json.load(open(os.path.join(BASE, 'glossary.json')))          # {'characters':[...], 'terms':[...]}
spk_disp = json.load(open(os.path.join(BASE, 'speakers.json')))
DLG = re.compile(r'^([A-Z][A-Z0-9]*?)_(\d+)$')
W = lambda s: len(s.split())

chars_by_id = {c['speakerId']: c for c in gl['characters'] if c.get('speakerId')}
display_keys = set()
for k, v in en:
    kk = re.sub(r'[^A-Z0-9]', '', k.upper())
    if kk in spk_disp and not DLG.match(k) and not k.startswith('/'):
        display_keys.add(k)

def speaker_info(sid):
    grp = 'BARKSRANGER' if sid.startswith('BARKSRANGER') else sid
    c = chars_by_id.get(sid)
    name = spk_disp.get(sid) or sid
    g = c['gender'] if c else 'U'
    if grp == 'BARKSRANGER':
        g = 'U'
    gtxt = {'M': 'male', 'F': 'female', 'N': 'non-human/group', 'U': 'unknown gender - use neutral phrasing'}[g]
    ar = c['arabic'] if c else ''
    return grp, f'{name} ({gtxt})' + (f' [Arabic name: {ar}]' if ar else '')

units = {}          # unit id -> {'en':..., 'keys':[...]}
dialogue, choices, other = [], [], []
seen_dlg, seen_nd = {}, {}
for idx, (k, v) in enumerate(en):
    if k in display_keys:
        continue                      # speaker labels are filled from the glossary
    m = DLG.match(k)
    if m:
        grp, label = speaker_info(m.group(1))
        key = (grp, v)
        if key in seen_dlg:
            units[seen_dlg[key]]['keys'].append(k); continue
        uid = f'd{len(dialogue):05d}'
        seen_dlg[key] = uid
        units[uid] = {'en': v, 'keys': [k]}
        dialogue.append((int(m.group(2)), uid, k, label, v))
    elif k.startswith('CHOICE_'):
        uid = f'c{len(choices):05d}'
        units[uid] = {'en': v, 'keys': [k]}
        choices.append((idx, uid, k, 'Dylan (male) - player dialogue choice', v))
    else:
        if v in seen_nd:
            units[seen_nd[v]]['keys'].append(k); continue
        uid = f'u{len(seen_nd):05d}'
        seen_nd[v] = uid
        if W(v) > 400:
            # split long legal/document text at paragraph boundaries; parts are re-joined on assembly
            pieces = re.split(r'(?<=<br>)|(?<=</p>)|(?<=</li>)|(?<=\n)', v)
            parts, cur = [], ''
            for p in pieces:
                if cur and W(cur) + W(p) > 250:
                    parts.append(cur); cur = ''
                cur += p
            if cur:
                parts.append(cur)
            assert ''.join(parts) == v
            units[uid] = {'en': v, 'keys': [k], 'parts': len(parts)}
            for pi, p in enumerate(parts):
                other.append((idx, f'{uid}~{pi:03d}', k + f' (part {pi + 1}/{len(parts)})', '', p))
        else:
            units[uid] = {'en': v, 'keys': [k]}
            other.append((idx, uid, k, '', v))

def natkey(k):
    return [int(t) if t.isdigit() else t for t in re.split(r'(\d+)', k)]
dialogue.sort()
other.sort(key=lambda r: natkey(r[2]))

# glossary lookup for per-batch subsets
GTXT = {'M': 'male', 'F': 'female', 'N': 'neutral/non-human', 'U': 'gender unknown'}
char_terms, world_terms, ui_terms = [], [], []
for c in gl['characters']:
    for e in re.split(r'\s*/\s*', c['english']):
        if e and len(e) >= 2:
            char_terms.append((e, f"{c['english']} = {c['arabic']} ({GTXT[c['gender']]}{'; ' + c['role'][:80] if c.get('role') else ''})"))
for t in gl['terms']:
    line = f"{t['english']} = {t['arabic']}" + (f" ({t['note'][:140]})" if t.get('note') else '')
    (ui_terms if t.get('category') == 'ui' else world_terms).append((t['english'], line))
def mk(pairs, flags=0):
    out = []
    for e, line in pairs:
        e = re.sub(r'\s*\(.*?\)\s*', ' ', e).strip()   # drop "(save)" style qualifiers
        for alt in re.split(r'\s*/\s*', e):
            alt = alt.strip(' .')
            if len(alt) >= 3 and not alt.isupper() or len(alt) >= 2 and alt.isupper():
                out.append((re.compile(r'(?<![A-Za-z])' + re.escape(alt) + r'(?![A-Za-z])', flags), line))
    return out
rx_chars = mk(char_terms)
rx_world = mk(world_terms)
rx_ui = mk(ui_terms)
ALWAYS = []
for c in gl['characters']:
    if c['speakerId'] in ('DYLAN', 'ZOE', 'JESSE', 'POPE', 'ARISH') or c['english'] in ('Dylan Faden', 'Zoe De Vera', 'Simon Arish'):
        ALWAYS.append(f"{c['english']} = {c['arabic']} ({GTXT[c['gender']]})")

def glossary_for(texts, kind):
    blob = '\n'.join(texts)
    out = list(dict.fromkeys(ALWAYS))
    groups = [rx_chars, rx_world] + ([rx_ui] if kind == 'other' else [])
    for g in groups:
        for rx, line in g:
            if line not in out and rx.search(blob):
                out.append(line)
    return out

NOTES = {
    'dialogue': 'Spoken dialogue/subtitles in script order (neighbouring lines are usually one conversation; use them for context: who is talking to whom, tone). The speaker and gender are given per line: the speaker\'s own verbs/adjectives follow the SPEAKER\'s gender; "you" follows the ADDRESSEE (Dylan = male; Zoe, Pope, Jesse = female). Lines of "FBC Ranger (unknown gender)" are combat barks shared by male and female voices: use gender-neutral phrasing.',
    'choice': 'Player dialogue choices shown on screen — the player is Dylan (male). Short, natural, as a line Dylan would say or a brief intent; keep them concise like a dialogue menu.',
    'other': 'Game text grouped by string key (the key prefix tells the context: MENU_* = UI/menus, ABILITY_*/WEAPON_*/TALENT_* = gameplay, OPCON_DOC_*/*_DOC_* = in-world documents, WQ_/MQ_/DQ_ = quests & objectives, TUTORIAL_* = tutorials, JRPG_* = retro JRPG mini-game, EULA/PRIVACY = legal text — translate completely and accurately). Anything addressed to the player uses masculine singular (the player is Dylan). Keep UI labels short.',
}

DONE = set()
for f in os.listdir(os.path.join(BASE, 'out')) if os.path.isdir(os.path.join(BASE, 'out')) else []:
    if f.endswith('.json'):
        try:
            DONE |= set(json.load(open(os.path.join(BASE, 'out', f))).keys())
        except Exception:
            pass
PREFIX = os.environ.get('BATCH_PREFIX', 'b')

def emit(rows, kind, target_words=2400, max_items=230, start_no=0):
    rows = [r for r in rows if r[1] not in DONE]
    batches, cur, words = [], [], 0
    prev_num = None
    for r in rows:
        num = r[0]
        gap = prev_num is not None and kind == 'dialogue' and num - prev_num > 2
        if cur and (words >= target_words * 1.25 or len(cur) >= max_items or (words >= target_words and (kind != 'dialogue' or gap))):
            batches.append(cur); cur, words = [], 0
        cur.append(r); words += W(r[4]) + 3; prev_num = num
    if cur:
        batches.append(cur)
    out = []
    for i, b in enumerate(batches):
        bid = f'{PREFIX}{start_no + i:03d}'
        items = []
        for r in b:
            it = {'id': r[1], 'key': r[2], 'en': r[4]}
            if r[3]:
                it['speaker'] = r[3]
            items.append(it)
        doc = {'batch': bid, 'kind': kind, 'notes': NOTES[kind], 'glossary': glossary_for([r[4] for r in b], kind), 'items': items}
        json.dump(doc, open(os.path.join(BASE, 'batches', bid + '.json'), 'w'), ensure_ascii=False, indent=1)
        out.append((bid, len(items), sum(W(r[4]) for r in b)))
    return out

os.makedirs(os.path.join(BASE, 'batches'), exist_ok=True)
for f in os.listdir(os.path.join(BASE, 'batches')):
    os.remove(os.path.join(BASE, 'batches', f))
info = []
info += emit(dialogue, 'dialogue', start_no=0)
info += emit(choices, 'choice', target_words=2000, max_items=300, start_no=len(info))
info += emit(other, 'other', start_no=len(info))
json.dump(units, open(os.path.join(BASE, 'units.json'), 'w'), ensure_ascii=False)
json.dump({'display_keys': sorted(display_keys)}, open(os.path.join(BASE, 'display_keys.json'), 'w'))
json.dump(info, open(os.path.join(BASE, 'batch_index.json'), 'w'))
print('batches', len(info), 'items', sum(i[1] for i in info), 'words', sum(i[2] for i in info))
print('largest', sorted(info, key=lambda x: -x[2])[:5])
