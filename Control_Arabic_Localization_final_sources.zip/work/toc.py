import struct, lz4.block
def read_toc(path):
    d=open(path,'rb').read()
    h=list(struct.unpack('<22I',d[:88]))
    assert d[:4]==b'COTR'
    ctoff,ctsize=h[2],h[3]
    n=ctsize//16
    chunks=[]; out=bytearray()
    for i in range(n):
        v,dec,comp=struct.unpack('<QII',d[ctoff+16*i:ctoff+16*i+16])
        off=v>>24; fl=v&0xffffff
        chunks.append((off,fl,dec,comp))
        if fl&0xff==0x10:
            out+=lz4.block.decompress(d[off:off+comp],uncompressed_size=dec)
        else:
            out+=d[off:off+dec]
    return h,chunks,bytes(out),d
def info(path):
    h,ch,dec,raw=read_toc(path)
    nblob=h[5]
    blobs=[]
    strs_off=h[10]
    def s(o,l): return dec[strs_off+o:strs_off+o+l].decode('utf8','replace')
    for i in range(nblob):
        no,nl,hsh,sz=struct.unpack('<IIQQ',dec[24*i:24*i+24])
        blobs.append((s(no,nl),hex(hsh),sz))
    return h,ch,dec,blobs
if __name__=='__main__':
    import sys
    for p in sys.argv[1:]:
        h,ch,dec,blobs=info(p)
        print('==',p,'hdr',[hex(x) for x in h[2:]],'dec',len(dec),'folders',h[7],'files',h[9])
        for b in blobs: print('  blob',b)

def files(h,dec):
    so=h[10]
    res=[]
    fo=h[8]
    for i in range(h[9]):
        A,folder,no,nl,size,B=struct.unpack('<QIIIIQ',dec[fo+32*i:fo+32*i+32])
        name=dec[so+no:so+no+nl].decode('utf8','replace')
        res.append(dict(i=i,A=A,folder=folder,name=name,size=size,B=B,ctoff=A&0xffffffff,ctlen=A>>32))
    return res
def chunks_for(h,dec,f):
    ct=h[20]
    out=[]
    for j in range(f['ctlen']//16):
        v,dsz,csz=struct.unpack('<QII',dec[ct+f['ctoff']+16*j:ct+f['ctoff']+16*j+16])
        out.append((v>>24,v&0xffffff,dsz,csz))
    return out
def read_file(h,dec,blobs,f):
    data=b''
    for off,fl,dsz,csz in chunks_for(h,dec,f):
        b=blobs[(fl>>8)&0xff]
        if fl&0xff==0x10: data+=lz4.block.decompress(b[off:off+csz],uncompressed_size=dsz)
        else: data+=b[off:off+dsz]
    return data
