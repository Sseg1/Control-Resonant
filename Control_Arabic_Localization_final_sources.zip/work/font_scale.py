#!/usr/bin/env python3
"""Enlarge the Arabic UI fonts inside the installed font patch.
Usage: python3 font_scale.py <in_dir> <out_dir> <factor>
in_dir holds the currently installed base-generic.rmdtoc + base-generic-000.rmdblob (from data_pack2/pc and data_pack2/generic).
Writes <out_dir>/data_pack2/pc/base-generic.rmdtoc and <out_dir>/data_pack2/generic/base-generic-000.rmdblob."""
import io, os, struct, sys
from fontTools.ttLib import TTFont
from fontTools.ttLib.scaleUpem import scale_upem
from toc import read_toc, files, chunks_for, read_file
from build_pack import write_toc, align

FONTS = ['alteredgrotesk-bold.otf', 'alteredgrotesk-bolditalic.otf', 'alteredgrotesk-italic.otf', 'alteredgrotesk-regular.otf']
GENERIC = b'../generic/base-generic-000.rmdblob'


def enlarge(data, factor):
    """Scale outlines, advances, kerning and vertical metrics by `factor`, keeping unitsPerEm:
    the text renders `factor` times larger at the game's normal size."""
    font = TTFont(io.BytesIO(data))
    upem = font['head'].unitsPerEm
    scale_upem(font, round(upem * factor))
    font['head'].unitsPerEm = upem
    if 'CFF ' in font:
        font['CFF '].cff.topDictIndex[0].FontMatrix = [1 / upem, 0, 0, 1 / upem, 0, 0]
    out = io.BytesIO(); font.save(out)
    return out.getvalue()


def main(in_dir, out_dir, factor):
    h, ch, dec, raw = read_toc(os.path.join(in_dir, 'base-generic.rmdtoc'))
    dec = bytearray(dec)
    oblob = open(os.path.join(in_dir, 'base-generic-000.rmdblob'), 'rb').read()
    # locate the generic blob in the blob list (24-byte entries: nameOff, nameLen, id, size)
    gi = next(i for i in range(h[5]) if (lambda no, nl: dec[h[10] + no:h[10] + no + nl])(*struct.unpack_from('<II', dec, 24 * i)) == GENERIC)
    fs = {f['name']: f for f in files(h, dec)}
    blob = bytearray(oblob[:16])  # keep blob header (magic + id)
    for n in FONTS:
        f = fs[n]
        cks = chunks_for(h, dec, f)
        assert len(cks) == 1 and (cks[0][1] >> 8) & 0xff == gi and cks[0][1] & 0xff == 0, (n, cks)
        data = enlarge(read_file(h, dec, [oblob if i == gi else None for i in range(h[5])], f), factor)
        off = align(len(blob)); blob += b'\0' * (off - len(blob))
        struct.pack_into('<I', dec, h[8] + 32 * f['i'] + 20, len(data))                      # file size
        struct.pack_into('<QII', dec, h[20] + f['ctoff'], (off << 24) | cks[0][1], len(data), 0)  # stored uncompressed
        blob += data
    blob += b'\0' * (align(len(blob)) - len(blob))
    # every chunk stored in the generic blob must be one of the fonts we rewrote
    others = [f['name'] for f in files(h, dec) if f['name'] not in FONTS and any((c[1] >> 8) & 0xff == gi for c in chunks_for(h, dec, f))]
    assert not others, others
    struct.pack_into('<Q', dec, 24 * gi + 16, len(blob))
    os.makedirs(os.path.join(out_dir, 'data_pack2', 'pc'), exist_ok=True)
    os.makedirs(os.path.join(out_dir, 'data_pack2', 'generic'), exist_ok=True)
    open(os.path.join(out_dir, 'data_pack2', 'generic', 'base-generic-000.rmdblob'), 'wb').write(blob)
    write_toc(os.path.join(out_dir, 'data_pack2', 'pc', 'base-generic.rmdtoc'), h, bytes(dec), ch)
    print(f'x{factor}: generic blob {len(oblob)} -> {len(blob)} bytes')


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], float(sys.argv[3]))
