import struct
MARK=b'\x3f\xb3\x4d\xd3'
def parse(d):
    assert d[:4]==b'RMDL'
    ver,z,c160,n,z2=struct.unpack('<5I',d[4:24])
    p=24; ids=[d[p+8*i:p+8*i+8] for i in range(n)]; p+=8*n
    entries=[]
    for i in range(n):
        assert d[p:p+4]==MARK, (i,p,d[p:p+16])
        cnt,size=struct.unpack('<II',d[p+4:p+12])
        start=p
        typ,zero,tl=struct.unpack('<III',d[p+12:p+24]); q=p+24
        text=d[q:q+tl].decode('utf8'); q+=tl
        sl=struct.unpack('<I',d[q:q+4])[0]; q+=4; spk=d[q:q+sl].decode('utf8'); q+=sl
        assert d[q:q+4]==MARK; q+=4
        assert q-start==size and cnt==2 and zero==0, (q-start,size,cnt)
        entries.append(dict(typ=typ,text=text,spk=spk))
        p=q
    footer=d[p:]
    return dict(hdr=d[:24],ids=ids,entries=entries,footer=footer)
def build(obj):
    out=bytearray(obj['hdr'])
    struct.pack_into('<I',out,16,len(obj['entries']))
    for i in obj['ids']: out+=i
    for e in obj['entries']:
        t=e['text'].encode('utf8'); s=e['spk'].encode('utf8')
        size=32+len(t)+len(s)
        out+=b'\x3f\xb3\x4d\xd3'+struct.pack('<IIII',2,size,e['typ'],0)+struct.pack('<I',len(t))+t+struct.pack('<I',len(s))+s+b'\x3f\xb3\x4d\xd3'
    out+=obj['footer']
    return bytes(out)
