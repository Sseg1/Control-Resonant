import struct, lz4.block
from toc import read_toc, files, chunks_for, read_file
from build_pack import write_toc, align

CHUNK = 0x100000

def repack(toc_in, blob_in, replace, toc_out, blob_out):
    """Rebuild a single-blob toc/blob pair. replace: {file_name: new_bytes}. All files are re-laid-out into a fresh blob."""
    h, ch, dec, raw = read_toc(toc_in)
    assert h[5] == 1, 'expects one blob'
    blob = open(blob_in, 'rb').read()
    dec = bytearray(dec)
    fl = files(h, dec)
    # sanity: every chunk entry belongs to exactly one file, contiguous per file
    total_entries = h[21] // 16
    assert sum(f['ctlen'] // 16 for f in fl) == total_entries, 'unreferenced chunk entries'
    newblob = bytearray(blob[:16])
    table = bytearray()
    for f in fl:
        old = chunks_for(h, dec, f)
        comp_flag = old[0][1] if old else 0x10
        data = replace.get(f['name'])
        if data is None:
            data = read_file(h, dec, [blob], f)
        # split like the original: same chunk count when possible (last chunk takes the remainder)
        n_old = max(1, len(old))
        last_max = max([CHUNK] + [c[2] for c in old])
        if len(data) <= CHUNK * (n_old - 1) + last_max:
            n = n_old
        else:
            n = -(-len(data) // CHUNK)
        pieces = []
        pos = 0
        for i in range(n):
            size = CHUNK if i < n - 1 else len(data) - pos
            pieces.append(data[pos:pos + size]); pos += size
        pieces = [p for p in pieces if p] or [b'']
        ctoff = len(table)
        for p in pieces:
            off = align(len(newblob)); newblob += b'\0' * (off - len(newblob))
            if (comp_flag & 0xff) == 0x10 and p:
                c = lz4.block.compress(p, mode='high_compression', compression=12, store_size=False)
                assert lz4.block.decompress(c, uncompressed_size=len(p)) == p
                newblob += c
                table += struct.pack('<QII', (off << 24) | (comp_flag & 0xffffff), len(p), len(c))
            else:
                newblob += p
                table += struct.pack('<QII', (off << 24) | (comp_flag & 0xffffff & ~0xff), len(p), 0)
        fe = h[8] + 32 * f['i']
        struct.pack_into('<Q', dec, fe, (len(pieces) * 16) << 32 | ctoff)
        struct.pack_into('<I', dec, fe + 20, len(data))
    newblob += b'\0' * (align(len(newblob)) - len(newblob))
    # replace chunk table (last section)
    assert h[20] + h[21] == len(dec)
    dec = dec[:h[20]] + table
    h = list(h); h[21] = len(table)
    # blob entry size (24-byte entries: nameOff, nameLen, id, size)
    if h[6] == 24 * h[5]:
        struct.pack_into('<Q', dec, 16, len(newblob))
    # recompute compressed-toc chunk layout for the new decompressed length
    chunks = []
    rem = len(dec)
    while rem > 0:
        s = min(CHUNK, rem); chunks.append((0, 0x10, s, 0)); rem -= s
    h[3] = 16 * len(chunks)
    write_toc(toc_out, h, bytes(dec), chunks)
    open(blob_out, 'wb').write(newblob)
    return len(newblob)

def verify(toc_path, blob_path, expected):
    h, ch, dec, raw = read_toc(toc_path)
    blob = open(blob_path, 'rb').read()
    bad = 0
    for f in files(h, dec):
        d = read_file(h, dec, [blob], f)
        if len(d) != f['size'] or (f['name'] in expected and expected[f['name']] != d):
            bad += 1
    return bad
