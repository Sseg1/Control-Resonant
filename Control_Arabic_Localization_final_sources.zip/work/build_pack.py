import struct, lz4.block, os
from toc import read_toc, files, chunks_for, read_file

def align(x,a=16): return (x+a-1)//a*a

def write_toc(path_out, h, dec, orig_chunks):
    """Recompress decompressed toc using the same chunk sizes as the source toc."""
    out_chunks=[]; pos=0
    for (_,fl,dsz,_) in orig_chunks:
        piece=dec[pos:pos+dsz]; pos+=dsz
        comp=lz4.block.compress(piece, mode='high_compression', compression=12, store_size=False)
        assert lz4.block.decompress(comp, uncompressed_size=dsz)==piece
        out_chunks.append((fl,dsz,comp))
    assert pos==len(dec)
    hdr=struct.pack('<22I',*h)
    table_off=h[2]; table_size=h[3]; assert table_size==16*len(out_chunks)
    data_start=0x1000
    body=bytearray(); entries=[]
    off=data_start
    for fl,dsz,comp in out_chunks:
        entries.append(struct.pack('<QII',(off<<24)|fl,dsz,len(comp)))
        body+=comp; pad=align(off+len(comp))-(off+len(comp)); body+=b'\0'*pad; off+=len(comp)+pad
    raw=bytearray(hdr)+b'\0'*(table_off-len(hdr))+b''.join(entries)
    raw+=b'\0'*(data_start-len(raw))+body
    open(path_out,'wb').write(raw)
    return bytes(raw)

if __name__=='__main__':
    # ---------- 1) generic: fonts into user's ORIGINAL toc ----------
    h,ch,dec,raw=read_toc('orig/data_pack2/pc/base-generic.rmdtoc')
    dec=bytearray(dec)
    oblob=open('orig/data_pack2/generic/base-generic-000.rmdblob','rb').read()
    fs={f['name']:f for f in files(h,dec)}
    blob=bytearray(oblob[:16])   # keep blob header (magic + id) exactly
    names=['alteredgrotesk-bold.otf','alteredgrotesk-bolditalic.otf','alteredgrotesk-italic.otf','alteredgrotesk-regular.otf']
    for n in names:
        data=open('fonts_out/'+n,'rb').read()
        off=align(len(blob)); blob+=b'\0'*(off-len(blob)); 
        f=fs[n]
        cks=chunks_for(h,dec,f); assert len(cks)==1 and (cks[0][1]>>8)&0xff==2 and cks[0][1]&0xff==0
        # file entry size
        fe=h[8]+32*f['i']; struct.pack_into('<I',dec,fe+20,len(data))
        # chunk entry: offset, decompressed size, stored uncompressed (csz=0)
        ce=h[20]+f['ctoff']; fl=cks[0][1]
        struct.pack_into('<QII',dec,ce,(off<<24)|fl,len(data),0)
        blob+=data
    blob+=b'\0'*(align(len(blob))-len(blob))
    # blob list entry #2 (../generic/base-generic-000.rmdblob) size
    bn=dec[h[10]:h[10]+0].decode()
    no,nl,hsh,sz=struct.unpack('<IIQQ',dec[48:72]); assert dec[h[10]+no:h[10]+no+nl]==b'../generic/base-generic-000.rmdblob'
    struct.pack_into('<Q',dec,64,len(blob))
    os.makedirs('out/data_pack2/pc',exist_ok=True); os.makedirs('out/data_pack2/generic',exist_ok=True)
    open('out/data_pack2/generic/base-generic-000.rmdblob','wb').write(blob)
    write_toc('out/data_pack2/pc/base-generic.rmdtoc',h,bytes(dec),ch)
    print('generic blob',len(blob))

    # ---------- 2) base-en: compact mod blob (drop unreferenced data), content unchanged ----------
    h,ch,dec,raw=read_toc('mod/data_pack2/pc/base-en.rmdtoc')
    dec=bytearray(dec)
    mblob=open('mod/data_pack2/pc/base-en-000.rmdblob','rb').read()
    nb=bytearray(mblob[:16]); remap={}
    for i in range(h[21]//16):
        ce=h[20]+16*i
        v,dsz,csz=struct.unpack('<QII',dec[ce:ce+16]); off=v>>24; fl=v&0xffffff
        assert (fl>>8)&0xff==0
        stored=csz if csz else dsz
        key=(off,stored)
        if key not in remap:
            no=align(len(nb)); nb+=b'\0'*(no-len(nb)); nb+=mblob[off:off+stored]; remap[key]=no
        struct.pack_into('<Q',dec,ce,(remap[key]<<24)|fl)
    nb+=b'\0'*(align(len(nb))-len(nb))
    open('out/data_pack2/pc/base-en-000.rmdblob','wb').write(nb)
    write_toc('out/data_pack2/pc/base-en.rmdtoc',h,bytes(dec),ch)
    print('base-en blob',len(mblob),'->',len(nb))
